import React from "react";
import { Header } from "./Header";
import Navbar from "./Navbar";

export default function Accueil() {
  return (
    <div>
      <Navbar />
      <Header />
    </div>
  );
}
